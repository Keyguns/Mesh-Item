#include <stm32f10x_gpio.h>
#include <stm32f10x_rcc.h>
#include <misc.h>
#include <delay.h>

#define Key0_in PCin(5)
#define Key1_in PAin(15)
#define KeyUP PAin(0);


#define LED0_Out PAout(12)
#define LED1_Out PDout(2)

//���ö��ֹ��ܵĽӿ��书�ܸ��ݳ�ʼ��ʹ�ܣ�����Ҫʲô���ܾͳ�ʼ��ʲô����
 void LED_init()
 {
	 GPIO_InitTypeDef GPIO_ITS;
	 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	 GPIO_ITS.GPIO_Mode=GPIO_Mode_Out_PP;
	 GPIO_ITS.GPIO_Pin=GPIO_Pin_12;
	 GPIO_ITS.GPIO_Speed=GPIO_Speed_50MHz;
	 GPIO_Init(GPIOA,&GPIO_ITS);
 }
 void LED()
 {
	 LED0_Out=1;
	 delay_ms(200);
	 LED0_Out=0;
	 delay_ms(200);
 }
	 
void Key_init()
 {
	 GPIO_InitTypeDef GPIO_ITS;
	 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOC,ENABLE);
	 GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);
	 GPIO_ITS.GPIO_Mode=GPIO_Mode_IPU;
	 GPIO_ITS.GPIO_Pin=GPIO_Pin_5;
	 GPIO_Init(GPIOC,&GPIO_ITS);
	 GPIO_ITS.GPIO_Pin=GPIO_Pin_15;
	 GPIO_Init(GPIOA,&GPIO_ITS);
	 GPIO_ITS.GPIO_Pin=GPIO_Pin_0;
	 GPIO_ITS.GPIO_Mode=GPIO_Mode_IPD;
	 GPIO_Init(GPIOA,&GPIO_ITS);
	 
 }
void Key0()
 {
	 if(Key0_in==0)
		 delay_ms(15);
		if(Key0_in==0)
			LED1_Out=!LED1_Out;
		delay_ms(100);
			
 }


 

 