
void Key_init(void);
void Key0(void);
void init_gpio(void);

//IIC
void iic_write_1(unsigned char big,unsigned char small,unsigned char value);
unsigned char iic_read_1(unsigned char big,unsigned char small);\

//MPU6050
void MPU6050_init(void);
void accelerationinit(void);
void accelerationx(void);
void accelerationy(void);
void accelerationz(void);
void accelerationvalue(void);
void gyroscopeinit(void);
void gyroscopex(void);
void gyroscopey(void);
void gyroscopez(void);

void gyroscopevalue(void);
void test(void);

//USART
void usart_init1(int bound);
void usart_init2(int bound);
void usart_init3(int bound);


//LED
void LED_init(void);
void LED(void);

//TIM
void TIM3_init(unsigned short arr,unsigned short psc);

//power
void power_gpio(void);
void TIM1_init(unsigned short arr,unsigned short psc);
void POWER_init(unsigned short arr,unsigned short psc);
void Power_test();


