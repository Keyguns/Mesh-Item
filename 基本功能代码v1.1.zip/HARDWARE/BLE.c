#include <stm32f10x_gpio.h>
#include <hardware.h>

#define PWRC PAout(7)
#define STAT PAin(0)
void BLE_GPIO(void);
void BLE_init()
{
	BLE_GPIO();
	/*������ATָ��*/
	/*
	printf("AT+NETIDC0C1C2C3C4C5\r\n");
	printf("AT+NAME15181\r\n");
	printf("AT+MADDR03\r\n");
	printf("AT+RESET\r\n");
	*/
	BLE_AT();
	printf("reset\r\n");
	BLE_Transmit();
		
}
void BLE_Status()
{
	if(STAT==1)
		OLED_ShowString (72,48,"link  ",16),OLED_Refresh();
	else 
		OLED_ShowString	(72,48,"await ",16),OLED_Refresh();	
}
void BLE_AT()
{
	PWRC=0;	
}
void BLE_Transmit()
{
	PWRC=1;
}

void  BLE_GPIO()
{
	GPIO_InitTypeDef GPIO_ITD;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	GPIO_ITD.GPIO_Pin=GPIO_Pin_9;
	GPIO_ITD.GPIO_Mode=GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA,&GPIO_ITD);
	GPIO_ITD.GPIO_Pin=GPIO_Pin_7;
	GPIO_Init(GPIOA,&GPIO_ITD);
}
void DataManager(char * blue_code)
{
	char i=3;
	for(;i<6;i++)
	*(blue_code+i)=*(blue_code+i)-48;
	
}

