#include <delay.h>
#include <usart.h>
#include <sys.h>
#include <oled.h>

void key_init(void);
void exti_init(void);
void oled_init(void);
void out_num(int in);


#define Key_1 PFin(1)
#define Key_2 PFin(2)
#define Key_3 PFin(3)
#define Key_4 PFin(4)
#define Key_5 PFin(5)
//////////////////////////////////////////


//comunicate

//IIC
void iic_write_1(unsigned char big,unsigned char small,unsigned char value);//ֻдһ���ֽ�
unsigned char iic_read_1(unsigned char big,unsigned char small);//ֻ��һ���ֽ�

//frame
//char mode,device,small_add;				//mode--ѡ��ģʽ��device--ѡ��C08�е�
//char input_code[3],output_code[3];

//AT24C08
void write_test(void);
char read_test(void);
void save_infrared_code(char * input_code,char device,char small_add);
void read_infrared_code(char * output_code,char device,char small_add);
void output_infrared_code(char* output_code);
char specific_address(char device,char small_add);

//infrared
	//char infr_code[3];
//JDY-10M
void BLE_init(void);
void BLE_Status(void);								//�ж���������״̬
void BLE_AT(void);
void BLE_Transmit(void);
void DataManager(char*blue_code);

	//char blue_code[6];

//OLED
void oled_show(void);
void oled_mode(char mode);
void oled_address(char device,char small_add);
void oled_device(char device);

//LED
void led_init(void);
void led(void);