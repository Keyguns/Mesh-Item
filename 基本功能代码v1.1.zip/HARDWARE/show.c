#include  <hardware.h>
#include  <oled.h>
//IIC_OLED��ʾ����
//IIC_SCL--PE6,IIC_SDA--PE4
//�޸�IIC������Ҫ�޸�oled.h�й������ŵĺ궨�壬�Լ�������ų�ʼ������
//OLED_ShowChar(x,y,'content',16);
//void OLED_ShowNum(u8 x,u8 y,u32 num,u8 len,u8 size1)
//28--'<'
void oled_show()
{
	OLED_ShowString(0,0, "Infrared",16);
	OLED_ShowString(0,16,"AT24C08 ",16);
	OLED_ShowString(0,32,"Device  ",16);
	OLED_ShowString(0,48,"BLE MESH",16);
	OLED_Refresh();
}

void oled_mode(char mode)
{
	if(mode==1)
		OLED_ShowString(72,0,"STUDY",16),OLED_Refresh();
	else
		OLED_ShowString(72,0,"WORK ",16),OLED_Refresh();
}
void oled_address(char device,char small_add)
{
	int spe_add;
	spe_add=specific_address(device,small_add);
	OLED_ShowNum(72,16,spe_add,3,16);	
}
void oled_device(char device)
{
	OLED_ShowNum(72,32,device,2,16);
}
void led_init()
{
	GPIO_InitTypeDef GPIO_ITD;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	GPIO_ITD.GPIO_Pin=GPIO_Pin_13;
	GPIO_ITD.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_ITD.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOC,&GPIO_ITD);
}
void led()
{
	GPIO_SetBits(GPIOC,GPIO_Pin_13);
	delay_ms(500);
	GPIO_ResetBits(GPIOC,GPIO_Pin_13);
	delay_ms(500);
}
/*void oled_init()
{
	delay_init();
	OLED_Init();
	OLED_ColorTurn(0);
	OLED_DisplayTurn(0);
	OLED_Refresh();
	OLED_ShowString(0,0,"ELEC Gun",16);
	OLED_ShowString(70,0,"SET UP",16);
	OLED_ShowString(0,16,"DISTANCE",16);				//����
	OLED_ShowNum(70,16,0,3,16);									//��ʼ����
	OLED_ShowString(98,16,"cm",16);
	OLED_ShowString(118,16,"<",16);
	OLED_ShowString(0,32,"ANGLE",16);						//�Ƕ�
	OLED_ShowString(70,32,"+",16);
	OLED_ShowNum(78,32,0,2,16);									//��ʼ�Ƕ�
	OLED_ShowChinese(98,32,14,16);//du
	OLED_ShowString(0,48,"MODE",16);						//ģʽ
	OLED_ShowString(70,48,"MANUAL",16);					
	OLED_Refresh();
}
void oled_test()
{
	
}*/