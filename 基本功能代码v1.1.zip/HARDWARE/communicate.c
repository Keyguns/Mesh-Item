#include <usart.h>
#include <hardware.h>

void out_num(int in)
{
	if(in>=0)
	{
		if(in<10)
			printf("%d",0),printf("%d",0),printf("%d",in);
		if(in<100&&in>=10)
			printf("%d",0),printf("%d",in);
		if(in>=100)
			printf("%d",in);
	}
	else
	{
		if(in<10)
			printf("%c",'9'),printf("%d",0),printf("%d",-in);
		if(in<100&&in>=10)
			printf("%c",'9'),printf("%d",-in);
		
	}
}
void send(int dist,int angl,char mo)
{
	out_num(mo);      			//000 ������//001 
	out_num(angl);
	out_num(dist);													
}



