#include <stm32f10x_gpio.h>
#include <stm32f10x_rcc.h>
#include <stm32f10x_usart.h>
#include <usart.h>
#include <stm32f10x_exti.h>
#include <oled.h>
#include <hardware.h>
#include <delay.h>

#define Shoot PAout(2)
extern int distance,angle;
extern char input_mode,mode,status;
int angle_relay;
//��ʼ������ PF-1 PF-2  PF-3 PF-4 PF-5
void show_angle(int anngle);

void key_init()
{
	GPIO_InitTypeDef GPIO_ITD;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF,ENABLE);
	GPIO_ITD.GPIO_Pin=GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5;
	GPIO_ITD.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_Init(GPIOF,&GPIO_ITD);
}

void exti_init()											
{
	EXTI_InitTypeDef EXTI_ITD;
	NVIC_InitTypeDef NVIC_ITD;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOF,GPIO_PinSource1);
	EXTI_ITD.EXTI_Line=EXTI_Line1;
	EXTI_ITD.EXTI_Mode=EXTI_Mode_Interrupt;
	EXTI_ITD.EXTI_Trigger=EXTI_Trigger_Falling;
	EXTI_ITD.EXTI_LineCmd=ENABLE;
	EXTI_Init(&EXTI_ITD);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOF,GPIO_PinSource2);
	EXTI_ITD.EXTI_Line=EXTI_Line2;
	EXTI_Init(&EXTI_ITD);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOF,GPIO_PinSource3);
	EXTI_ITD.EXTI_Line=EXTI_Line3;
	EXTI_Init(&EXTI_ITD);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOF,GPIO_PinSource4);
	EXTI_ITD.EXTI_Line=EXTI_Line4;
	EXTI_Init(&EXTI_ITD);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOF,GPIO_PinSource5);
	EXTI_ITD.EXTI_Line=EXTI_Line5;
	EXTI_Init(&EXTI_ITD);
	
	NVIC_ITD.NVIC_IRQChannel=EXTI1_IRQn;
	NVIC_ITD.NVIC_IRQChannelPreemptionPriority=2;
	NVIC_ITD.NVIC_IRQChannelSubPriority=2;
	NVIC_ITD.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_ITD);
	NVIC_ITD.NVIC_IRQChannel=EXTI2_IRQn;
	NVIC_Init(&NVIC_ITD);
	NVIC_ITD.NVIC_IRQChannel=EXTI3_IRQn;
	NVIC_Init(&NVIC_ITD);
	NVIC_ITD.NVIC_IRQChannel=EXTI4_IRQn;
	NVIC_Init(&NVIC_ITD);
	NVIC_ITD.NVIC_IRQChannel=EXTI9_5_IRQn;
	NVIC_Init(&NVIC_ITD);
	
	
}
void EXTI1_IRQHandler()										//PF-1  ִ��+
{
	delay_ms(10);
	if(input_mode==0)
		distance ++,OLED_ShowNum(70,16,distance,3,16),OLED_Refresh();
	else
		angle++,show_angle(angle);
	delay_ms(100);
	EXTI_ClearITPendingBit(EXTI_Line1);
}
void EXTI2_IRQHandler()										//PF-2  ִ��-
{
	delay_ms(10);
	if(input_mode==0)
	{
		distance --;
		if(distance<0)
			distance=0;
		OLED_ShowNum(70,16,distance,3,16),OLED_Refresh();
	}
	else
	{ 
		angle --;
		show_angle(angle);
	}
	delay_ms(100);
	EXTI_ClearITPendingBit(EXTI_Line2);
	
}
void EXTI3_IRQHandler()										//PF-3 	�л��ǶȺ;���
{
	delay_ms(10);
	if(Key_3==0)
	{
		input_mode=!input_mode;
		if(input_mode)
			OLED_ShowString(118,32,"<",16),OLED_ShowString(118,16," ",16),OLED_Refresh();			//Angle
		else
			OLED_ShowString(118,32," ",16),OLED_ShowString(118,16,"<",16),OLED_Refresh();			//Distance
		
	}
	delay_ms(100);
	EXTI_ClearITPendingBit(EXTI_Line3);
}
void EXTI4_IRQHandler()										//PF-4  �ֶ�,�Զ�,Ѳ��ģʽ�л�
{
	delay_ms(10);
	if(Key_4==0)
	{
		mode++;
		if(mode==4)
			mode=1;
		switch(mode)
		{
			case 1: OLED_ShowString(70,48,"MANUAL",16),OLED_Refresh();break;
			case 2: OLED_ShowString(70,48,"AUTO  ",16),OLED_Refresh();break;
			case 3: OLED_ShowString(70,48,"CRUISE",16),OLED_Refresh();break;
		}
	}
	delay_ms(100);	
	EXTI_ClearITPendingBit(EXTI_Line4);
}
void EXTI9_5_IRQHandler()									 //PF-5	 ����/׼��
{
	delay_ms(10);
	if(Key_5==0)
	{
		status=!status;
		if(status==0)
			OLED_ShowString(70,0,"SET UP",16),OLED_Refresh();
		else
		{
			OLED_ShowString(70,0,"FIRE  ",16),OLED_Refresh();
			send(distance,angle,mode);
		}
		if(mode==1)
		{
			Shoot=1;
			delay_ms(100);
			Shoot=0;
		}
			
			
	}
	delay_ms(100);
	EXTI_ClearITPendingBit(EXTI_Line5);
}

void show_angle(int anngle)
{
	if(angle>=0)
	{
		OLED_ShowString(70,32,"+",16);
		OLED_ShowNum(78,32,angle,2,16);
		OLED_Refresh();
	}
	else
	{
		OLED_ShowString(70,32,"-",16);
		OLED_ShowNum(78,32,angle*(-1),2,16);
		OLED_Refresh();
	}
}


